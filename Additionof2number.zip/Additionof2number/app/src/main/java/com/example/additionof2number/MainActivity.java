package com.example.additionof2number;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText n,n1;
    Button add_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        n = findViewById(R.id.editTextText);
        n1 = findViewById(R.id.editTextText2);
        add_btn = findViewById(R.id.button);
        add_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int value_1=Integer.parseInt(n.getText().toString());
                int value_2=Integer.parseInt(n1.getText().toString());
                int sum =value_1+value_2;

                Toast.makeText(MainActivity.this,"Addition of Both numbers "+sum,Toast.LENGTH_LONG).show();
            }
        });
    }
}